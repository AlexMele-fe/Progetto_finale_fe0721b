export const environment = {
  production: true,
  pathApi: 'http://epicode.online/epicodebeservice_v2',
  adminToken: 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImlhdCI6MTY0NjgzNTA5MCwiZXhwIjoxNjQ3Njk5MDkwfQ.7DBfLNKE-oK5z-uM2_R03uq_izaEXWPKdj33TpgUtUFW_FFHGPep5qFDPWS-b9FnASFVJk09_Efz-C8SDsn--A',
  adminTenant:'fe_0721b'
};
