import { Component, OnInit } from '@angular/core';

@Component({
  template: `
    <p>
      home works!
    </p>
  `,
  styles: [
  ]
})
export class HomePage implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
